package modelo.dao;

public class consultaDao {
    
}
