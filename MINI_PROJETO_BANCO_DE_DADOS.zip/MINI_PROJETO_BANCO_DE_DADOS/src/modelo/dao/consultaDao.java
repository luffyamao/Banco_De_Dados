package modelo.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class consultaDao extends abstratoDao {
    public boolean adicionar (int matricula, String cpf, LocalDateTime horario, int valor) {
        boolean sucesso;
        String sql = "insert into consulta (id_medico, id_paciente) values" + "((select id from medico where matricula = ?), (select id from paciente where cpf = ?), (select horario from consulta where horario = ?), (select valor from consulta where valor = ?))";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, matricula);
            stmt.setString(2, cpf);
            stmt.setString(3, horario);
            stmt.setInt(4, valor);

            sucesso = stmt.executeUpdate() == 1;
        } catch (SQLException e) {
            sucesso = false;
        }

        return sucesso;

    }
