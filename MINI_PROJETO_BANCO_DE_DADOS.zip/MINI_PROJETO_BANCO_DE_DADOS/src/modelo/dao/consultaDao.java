package modelo.dao;
import modelo.entidade.Consulta;
import modelo.entidade.Medico;
import modelo.entidade.Paciente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


public class consultaDao extends abstratoDao {
    public boolean adicionar (int matricula, String cpf, LocalDateTime horario, int valor) {
        boolean sucesso;
        String sql = "insert into consulta (id_medico, id_paciente) values" + "((select id from medico where matricula = ?), (select id from paciente where cpf = ?), (select horario from consulta where horario = ?), (select valor from consulta where valor = ?))";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, matricula);
            stmt.setString(2, cpf);
            stmt.setObject(3, horario);
            stmt.setFloat(4, valor);

            sucesso = stmt.executeUpdate() == 1;
        } catch (SQLException e) {
            sucesso = false;
        }

        return sucesso;

    }

    public boolean remover (int matricula, String cpf, LocalDateTime horario, int valor) {
        boolean sucesso;
        String sql = "delete from consulta where id_medico = (select id from medico where matricula = ?)" + " and id_paciente = (select id from paciente where cpf = ?)";

        try (PreparedStatement stmt = conexao.prepareStatement(sql)){
            stmt.setInt(1, matricula);
            stmt.setString(2, cpf);
            stmt.setObject(3, horario);
            stmt.setFloat(4, valor);

            sucesso = stmt.executeUpdate() == 1;
        } catch (Exception e) {
            sucesso = false;
        }
        return sucesso;

    }

    public boolean atualizar (int matricula, String cpf, LocalDateTime novoHorario, int valor) {
        boolean sucesso;
        String sql = "update consulta set horario = ? where id_medico = (select id from medico where matricula = ?)" + "and id_paciente = (select id from paciente where cpf = ?)"; 

        try (PreparedStatement stmt = conexao.prepareStatement(sql)){
            stmt.setInt(1, matricula);
            stmt.setString(2, cpf);
            stmt.setObject(3, novoHorario);
            stmt.setFloat(4, valor);

            sucesso = stmt.executeUpdate() == 1;
        } catch (Exception e) {
            sucesso = false;
            e.printStackTrace();
        }
        return sucesso;
    }

    public List<Consulta> listar() {
        List<Consulta> consultas = new ArrayList<>();
        String sql = "select medico.* paciente.* from consulta inner join medico on" + "medico.id = consulta.id_medico inner join paciente on paciente.id = consulta.id_paciente";

        try (PreparedStatement stmt = conexao.prepareStatement(sql); ResultSet st = stmt.executeQuery()) {

            while (st.next()) {

                Medico m = new Medico(st.getString("medico.nome"), st.getInt("medico.matricula"), st.getString("medico.especialidade"), st.getFloat("medico.salario"));
                Paciente p = new Paciente(st.getString("paciente.nome"), st.getString("paciente.cpf"), st.getString("paciente.doenca")); 
                Consulta c = new Consulta(m, p, st.getObject("consulta.horario", LocalDateTime.class), st.getFloat("consulta.valor"));

                consultas.add(c);
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return consultas;
    }
}