package modelo.entidade;
import java.time.LocalDateTime;

public class Consulta {
    
    private Medico medico;
    private Paciente paciente;
    private LocalDateTime horario;


    public Consulta() {
    }


    public Consulta(Medico medico, Paciente paciente, LocalDateTime horario) {
        this.medico = medico;
        this.paciente = paciente;
        this.horario = horario;
    }


    public Medico getMedico() {
        return this.medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public Paciente getPaciente() {
        return this.paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public LocalDateTime getHorario() {
        return this.horario;
    }

    public void setHorario(LocalDateTime horario) {
        this.horario = horario;
    }

}
