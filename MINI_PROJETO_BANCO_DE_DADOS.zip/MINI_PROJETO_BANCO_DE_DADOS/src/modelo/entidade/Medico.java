package modelo.entidade;

public class Medico {

    private String nome;
    private int matricula;
    private String especialidade;
    private int salario;


    public Medico() {
    }


    public Medico(String nome, int matricula, String especialidade, int salario) {
        this.nome = nome;
        this.matricula = matricula;
        this.especialidade = especialidade;
        this.salario = salario;
    }


    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatricula() {
        return this.matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getEspecialidade() {
        return this.especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public int getSalario() {
        return this.salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

}
