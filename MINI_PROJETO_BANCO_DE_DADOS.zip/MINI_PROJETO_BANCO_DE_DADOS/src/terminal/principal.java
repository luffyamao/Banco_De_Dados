package terminal;
import modelo.dao.medicoDao;
import modelo.entidade.Consulta;
import modelo.entidade.Medico;
import modelo.entidade.Paciente;
import java.sql.SQLException;
import java.util.Scanner;

public class principal {

    public static void main(String[] args) {
        var teclado = new Scanner(System.in);

        while (true) {
            System.out.println("-----------------------");
			System.out.println("00. Encerrar o programa");
			System.out.println("01. Cadastrar novo médico");
			System.out.println("02. Cadastrar novo paciente");
			System.out.println("03. Buscar médico por matrícula");
			System.out.println("04. Buscar paciente por CPF");
			System.out.println("05. Cadastrar uma nova consulta");
			System.out.println("06. Remover uma consulta");
			System.out.println("07. Atualizar horário da consulta");
			System.out.println("08. Gerar relatório de consultas");
			System.out.print("Escolha sua opção: ");
            int opcao = teclado.nextInt();
            teclado.nextLine();

            if (opcao == 0) {
                System.out.println("Saindo do programa...");
				break;
            } else if (opcao == 1) {
                Medico medico = new Medico();

                System.out.println("Digite o nome do médico: ");
                medico.setNome(teclado.nextLine());

                System.out.println("Digite a matricula do médico: ");
                medico.setMatricula(teclado.nextInt());
                teclado.nextLine();

                System.out.println("Digite a especialidade: ");
                medico.setEspecialidade(teclado.nextLine());

                System.out.println("Digite o salário do médico: ");
                medico.setSalario(teclado.nextFloat());
                teclado.nextLine();

                if (new medicoDao().adicionar(medico))
                    System.out.println("Médico adicionado com sucesso!");
                else
                    System.out.println("Erro ao cadastrar!!");
            }
        }
    }
}