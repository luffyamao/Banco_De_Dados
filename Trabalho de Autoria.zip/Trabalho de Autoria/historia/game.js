function pagJogo (event) {
    event.preventDefault();
    window.location.href = "../jogo/index.html"
}

function continuarHistory() {
    window.location.href = "../login/index.html"
}

function newpage () {
    window.location.href = "../portfolio/index.html"
}
