function adicionar(event) { 
    event.preventDefault();
    var nome = document.getElementById("nome")
    var apelido = document.getElementById("apelido")
    var idade = document.getElementById("idade")
    var musica = document.getElementById("musica")
    var cor = document.getElementById("cor")
    var comida = document.getElementById("comida")
    var cinema = document.getElementById("cinema")
    var amizade = document.getElementById("amizade")
    var lugar = document.getElementById("lugar")
    var inspiraçao = document.getElementById("inspiraçao")
    var louco = document.getElementById("louco")
    var sonho = document.getElementById("sonho")
    var profissao = document.getElementById("profissao")
    var trabalho = document.getElementById("trabalho")
    var desfazer = document.getElementById("desfazer")
    var suportar = document.getElementById("suportar")

    var bd = JSON.parse(localStorage.getItem("BancoDeDados"))

    if (bd == null) {
        localStorage.setItem("BancoDeDados", "[]")
        bd = [];
    }

    var info = {
        nome: nome.value,
        apelido: apelido.value,
        idade: idade.value,
        musica: musica.value,
        cor: cor.value,
        comida: comida.value, 
        cinema: cinema.value,
        amizade: amizade.value,
        lugar: lugar.value,
        inspiraçao: inspiraçao.value,
        louco: louco.value,
        sonho: sonho.value,
        profissao: profissao.value,
        trabalho: trabalho.value,
        desfazer: desfazer.value,
        suportar: suportar.value
    }

    bd.push(info)

    localStorage.setItem("BancoDeDados", JSON.stringify(bd))
    alert("Registro concluido!!")

    window.location.href = "../historia/index.html"
}

var historia = `Um garoto perdido em suas emoções, o que você tá fazendo aqui, ${nome.value}?`

var element = document.querySelector("historia")
var text = document.createTextNode(historia)

element.appendChild(text)
