function ganhou (event) {
  event.preventDefault();
  window.location.href = "../historia/final.html"

}

function perdeu () {
  window.location.href = "../jogo/index.html"
}