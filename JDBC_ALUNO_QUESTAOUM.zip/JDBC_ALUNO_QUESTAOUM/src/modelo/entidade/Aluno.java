package modelo.entidade;

public class aluno {
    private int num;
    private String nome;
    private String curso;
    private float nota1;
    private float nota2;
    private float nota3;
    private float nota4;
}

