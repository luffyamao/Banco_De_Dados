package modelo.dao;

import java.sql.PreparedStatement;

import modelo.entidade.Aluno;

public class AlunoDao extends AbstratoDao {
        public boolean adicionar (Aluno c) {
            boolean sucesso;
            String sql = "insert into aluno (numero, nome, curso, nota1, nota2, nota3, nota4) values (?, ?, ?, ?)";

            try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
                stmt.setString(1, c.getNome());
                stmt.setString(2, c.getCurso());
                stmt.setInt(3, c.getNum());
                stmt.setFloat(4, c.getNota1());
                stmt.setFloat(5, c.getNota2());
                stmt.setFloat(6, c.getNota3());
                stmt.setFloat(7, c.getNota4());

                sucesso = stmt.executeUpdate() == 1;
            } catch (Exception e) {
                sucesso = false;
            }

            return sucesso;
        }    
}
